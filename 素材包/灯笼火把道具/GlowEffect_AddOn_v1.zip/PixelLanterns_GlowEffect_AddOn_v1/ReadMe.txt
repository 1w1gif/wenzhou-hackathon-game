Pixel Paper Lanterns Vol. 1 — Glow Effects Add‑On
By HauntedBeautyStudios

Thank you for downloading the Glow Effects Add‑On!

This pack includes a universal glow sprite designed to be placed behind any lantern from Pixel Paper Lanterns Vol. 1. You can resize, reposition, and adjust opacity to match your scene and engine.

Included:
- Single glow style in multiple sizes:
  - 16×16, 128×128, 256×256, 512×512, 1080×1080
- 16‑bit high‑depth version for smoother gradients
- Spritesheet version (all glow sizes together)
- Preview GIF (example usage)

How to Use:
1. Place the glow sprite on a layer behind your lantern.
2. Scale the glow to roughly match the lantern’s size.
3. Adjust opacity to taste (lower opacity for subtle ambience, higher for dramatic lighting).
4. Optional: experiment with blend modes like Additive, Screen, or Soft Light if your engine supports them.

Common Issues & Troubleshooting:

Q: “I see a hard edge or a box around the glow.”
- Make sure the sprite is using alpha transparency (PNG) and not being converted to a format that removes transparency.
- Check that your engine isn’t applying color key transparency instead of alpha.
- If available, turn off “pixel smoothing” or “texture filtering” for a crisper edge.

Q: “The glow looks too bright or washed out.”
- Lower the opacity of the glow layer.
- Try a different blend mode (Normal vs Additive vs Screen).
- Avoid stacking multiple glow sprites directly on top of each other at full opacity.

Q: “The glow looks blurry or strange when scaled.”
- Use the size closest to your lantern’s resolution (e.g., 128×128 or 256×256).
- If your engine allows it, disable filtering for pixel‑perfect results.
- For very large scenes, use the 512×512 or 1080×1080 versions instead of scaling up a tiny one.

License:
You may use these glow effects in commercial and non‑commercial projects.
You may not redistribute or resell the assets as‑is or in other asset packs.

Thank you for supporting my work!
More packs and updates coming soon.
