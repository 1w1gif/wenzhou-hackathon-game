PIXEL UI KIT - FREE SAMPLE v1.0  -  by REEBOO Labs
====================================================
67 pixel-art UI sprites from the "Oak Tavern" theme (Wood frames): a real subset of the full pack,
same formats and same quality, so you can test it in your game.

Want all 742 sprites in 7 themes (wood, stone, parchment, metal, 2 sci-fi neon, flat)?
Get the full Pixel UI Kit for $6.99: https://reebo0.itch.io/pixel-ui-kit
(This sample also contains GET_THE_FULL_PACK.url.)

WHAT IS INSIDE (67 sprites)
--------------------------------
  panels    7  panel, inset panel, window, dialogue box, name plate, tooltip, focus ring
  buttons   16  small / medium / large x normal, hover, pressed, disabled + square button x 4 states
  controls  16  toggles, checkboxes, radio buttons, text fields, tabs, slider, scroll bar
  bars      8  health / mana / xp fills in 2 sizes + 2 bar frames
  slots     9  inventory slots: normal, hover, selected, disabled + 5 rarity colors
  icons     10  close, settings, home, pause, play, sound on, plus, check, star, heart (16x16)
  cursors   1  arrow cursor

Also: themes/wood/atlas_sample.png + atlas_sample.json (spritesheet with coordinates and 9-slice margins),
data/elements_sample.json, godot/theme_wood_sample.tres (Godot 4 Theme) and the pixel bitmap font.

FOLDERS
-------
PixelUIKit/themes/wood/png/<category>/<name>.png    sprites at native size, no antialiasing
PixelUIKit/themes/wood/atlas_sample.png/.json       spritesheet + 9-slice margins ("slice": left, top, right, bottom)
PixelUIKit/godot/theme_wood_sample.tres             Godot 4 Theme (Button, Panel, ProgressBar, HSlider, CheckBox, LineEdit, tabs ...)
PixelUIKit/font/                                      bitmap font used by the theme

GODOT 4 (tested with 4.4.1)
---------------------------
1. Copy the PixelUIKit folder into your project.
2. Set Project Settings > Rendering > Textures > Canvas Textures > Default Texture Filter = Nearest.
3. Assign res://PixelUIKit/godot/theme_wood_sample.tres as the Theme of a Control.
   Theme type variations in the sample: ButtonSmall, ButtonLarge, ButtonSquare, WindowPanel, InsetPanel, DialoguePanel,
   NamePlate, SlotNormal/Hover/Selected/Disabled, SlotCommon..SlotLegendary, HealthBar, ManaBar, XPBar (+ Large).
   The full pack adds more theme elements, 6 more themes and a demo scene.

UNITY / GAMEMAKER / OTHER
-------------------------
Plain RGBA PNGs: import with point filtering and no compression. 9-slice borders are in the JSON ("slice").

LICENSE
-------
Royalty-free for commercial and non-commercial games and apps. Credit appreciated, not required.
You may not resell or redistribute the assets as they are (alone or in an asset pack). See LICENSE.txt.

LINKS
-----
Full pack:   https://reebo0.itch.io/pixel-ui-kit
This sample: https://reebo0.itch.io/pixel-ui-kit-free-sample
